package com.example.vkmeans;

public class data1 {
    public String name,num,typ;
    //for combo
    public data1(String name, String num, String typ) {
        this.name = name;
        this.num = num;
        this.typ = typ;
    }

    public String getName() {
        return name;
    }

    public String getNum() {
        return num;
    }

    public String getTyp() {
        return typ;
    }
}
